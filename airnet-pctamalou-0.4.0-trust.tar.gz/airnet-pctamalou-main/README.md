# AirNet PCTamalou

**Le Réseau de la Liberté Pensante**  
Créé par **Platon-Y (Jonathan Ducros)** pour **PCTamalou** et **Echoes of Hackers**.

| Site | URL |
|------|-----|
| PCTamalou | https://pctamalou.fr |
| Echoes of Hackers | https://e-of-h.fr |
| Contact | admin@pctamalou.fr · admin@e-of-h.fr |

---

## Statut : 0.4.0-trust (sur-protection)

- **crypto** : `airnet.crypto` — seal/open X25519 + **canaux PSK** (HKDF + ChaCha20-Poly1305)
- **trust** : default **DENY** — `airnet-trust accept` après échange OOB
- **mesh** : IBSS + batman-adv → `bat0` (TX légal FR ≤ 20 dBm) — radio **non** chiffrée L2
- **transport** : UDP (port 41337), framing `AIR1` (MSG/VOICE/CHANNEL_MSG)
- **apps** : `airnet-node`, `airnet-connect`, `airnet-msg`, `airnet-voice`, `airnet-trust`, `airnet-channel`

Pas de mot de passe global. La confidentialité est **applicative** (acceptation + canaux).  
Voir [docs/trust.md](docs/trust.md) et [SECURITY.md](SECURITY.md).

---

## Installation

Python ≥ 3.10.

```bash
cd airnet-pctamalou-main
pip install -e ".[dev]"
# optionnel :
pip install -e ".[gui]"    # PyQt5
pip install -e ".[voice]"  # PyAudio
```

Outils mesh (terrain) : `iw`, `batctl`, module `batman-adv`.

---

## CLI

```bash
airnet-node --dry-run --no-mesh --bind 127.0.0.1
airnet-connect --no-mesh --timeout 10 --bind 127.0.0.1
airnet-trust accept --pub <hex64>
airnet-trust list
airnet-channel create --name soiree --show-secret
airnet-channel join --name soiree --secret '…'
airnet-msg --no-mesh --bind 127.0.0.1
airnet-msg --channel soiree -m "salut groupe"
airnet-voice --demo-chunk --to-pub <hex64>   # après accept, ou --channel
```

---

## Tests

```bash
pytest -q
```

---

## Cryptographie (aperçu)

```python
from airnet.crypto import generate_or_load_identity, seal, open
from airnet.trust import TrustStore

alice = generate_or_load_identity("./data/keys/alice")
bob = generate_or_load_identity("./data/keys/bob")
trust = TrustStore("./data/trust/bob")
trust.accept_peer(alice.public_bytes)  # Bob accepte Alice

blob = seal(b"hello mesh", bob.public_bytes, identity=alice)
# Bob n'ouvre que si accepté :
assert trust.is_accepted(alice.public_bytes)
plain = open(blob, alice.public_bytes, identity=bob)
```

Canaux :

```python
from airnet.crypto import ChannelStore
store = ChannelStore("./data/channels")
meta, secret = store.create("labo", channel_type="group")
# échanger secret OOB, puis store.join("labo", secret) chez les autres
ct = store.encrypt(meta, b"ping")
assert store.decrypt(meta, ct) == b"ping"
```

---

## Licences (duales — inchangées)

- **Usage perso / communautaire** : [GPLv3](LICENSE)
- **Usage commercial** : [APCL](LICENSE-APCL.md)

---

## Structure

```
airnet/
  crypto/       # seal/open + channel PSK
  trust/        # contacts accept / revoke (default DENY)
  mesh/         # IBSS + batman-adv + legal TX
  transport/    # framing AIR1 + UDP
  apps/         # node, connector, messenger, voice, trust, channel
legacy/         # musée (DEPRECATED)
tests/
docs/trust.md
TRUST_REPORT.md
```

---

## Soutien

- Dons : [paypal.me/pctamalou](https://www.paypal.com/paypalme/pctamaloufr/2)
- Kits : bientôt sur [pctamalou.fr](https://pctamalou.fr)

**Liberté. Pensée. Connexion.**
