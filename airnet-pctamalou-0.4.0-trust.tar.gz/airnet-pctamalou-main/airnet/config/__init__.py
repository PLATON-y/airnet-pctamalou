"""Configuration AirNet (defaults YAML)."""
